#ifndef MSG__H
#define MSG__H
#include <iostream>


using namespace std;

class Msg{
public:
    Msg();
    ~Msg();
    void writeString(string str);
    void printAsString();
    
    string to;
    string from;
    string data;
};

#endif
