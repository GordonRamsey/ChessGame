#include "Msg.h"



Msg::Msg(){
    to = "";
    from = "";
    data = "";
}

Msg::~Msg(){
}

void Msg::writeString(string str){
    data = str;
}

void Msg::printAsString(){
    cout << "msg: " << from << " -> " << to << " \"" << data << "\"\n";
    
}