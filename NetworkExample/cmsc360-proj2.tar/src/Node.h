#ifndef NODE__H
#define NODE__H
#include <iostream>
#include <sstream>
#include <unistd.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include "Mailbox.h"

using namespace std;

class Node : public Mailbox{
public:
	Node(string d);
    void join(string dest);
    void print();
    void handle(Msg* msg);
    void send(string dest,string m);
    
};

#endif
