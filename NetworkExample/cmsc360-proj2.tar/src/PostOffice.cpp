#include "PostOffice.h"


PostOffice::PostOffice(string id){
    char longname[256];
    gethostname(longname,256);
    
    struct addrinfo hints;
    struct addrinfo *info;
    
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_INET;  // or use AF_UNSPEC
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;
    
    getaddrinfo(longname, id.c_str(), &hints, &info);
    
    //This is the socket that will listen for connections
    listener = socket(info->ai_family, info->ai_socktype, 0);
    int error = bind(listener, info->ai_addr, info->ai_addrlen);
    
    freeaddrinfo(info);

    error = listen(listener,16);
    
    char ip[NI_MAXHOST];
    char service [NI_MAXSERV];
    getnameinfo(info->ai_addr, info->ai_addrlen, ip, sizeof(ip),service, sizeof(service),NI_NUMERICHOST | NI_NUMERICSERV);
    hostname = ip;
    port = service;
    
    FD_ZERO(&sockets);
    FD_SET(STDIN_FILENO, &sockets);
    FD_SET(listener, &sockets);
    
    maxFd = listener;
}

string PostOffice::getAddress(){
    return "@" + hostname + ":" + port;
}

//list the Mailboxs that this PostOffice knows about
void PostOffice::debug(){
    cout << "<--local boxes-->\n";
    for(map<string,Mailbox*>::iterator it=local.begin(); it != local.end(); ++it){
        Mailbox* mb = it->second;
        mb->print();
    }
    cout << "<--------------->\n";

}

//set up a new Mailbox
void PostOffice::makeBox(Mailbox* mb){
    if(mb == NULL)
        return;
    
    string address = mb->getId() + getAddress();
    
    if(local.find(address) == local.end()){
        local[address] = mb;
        mb->setAddress(address);
    }
}

Msg* PostOffice::createError(Msg* msg,string message){
    Msg* error = new Msg();
    error->to = msg->from;
    error->from = getAddress();
    error->writeString("opps " + message);
    return error;
}

//breaks down the message and handles sending information on a socket
Msg* PostOffice::route(string server,string porto,Msg* msg){
    struct addrinfo hints;
    struct addrinfo *info;
    
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;
    
    int result = getaddrinfo(server.c_str(), porto.c_str(), &hints,  &info);
    int theSocket = 0;
    if(result == 0){
        theSocket = socket(info->ai_family, info->ai_socktype, 0);
        result = connect(theSocket, info->ai_addr, info->ai_addrlen);
    }
    
    freeaddrinfo(info);

    Msg* error = NULL;
    if(result != 0){
        error = createError(msg,"could not connect");
        delete msg;
        msg = error;
    }else{
        stringstream parser;
        parser << msg->to << " " << msg->from << " " << msg->data;
        string d = parser.str();
        int sizes = d.size();
        write(theSocket,&sizes,sizeof(int));
        write(theSocket,d.c_str(),sizes*(sizeof (char)));
        close(theSocket);

         delete msg;
         msg = NULL;
     }
    
    return msg;
}

string PostOffice::parseHost(string addr){
    int start = addr.find_first_of('@');
    if( start >= addr.size() || start < 0){
        return addr;
    }
    int end = addr.find_last_of(':');
    if( end >= addr.size() || end < 0){
        return addr;
    }
    if( end < start){
        return addr;
    }
    return addr.substr(start+1,end-start-1);
}

string PostOffice::parsePort(string addr){
    int start = addr.find_first_of(':');
    if(start+1 >= addr.size() || start < 0)
        return addr;
    return addr.substr(start+1);
}


//takes a msg and tries to deliver it
Msg* PostOffice::deliver(Msg* msg){
    if(msg == NULL)
        return NULL;
    string poHost = parseHost(msg->to);
    string poPort = parsePort(msg->to);

    string poAddress = "@" + poHost + ":" + poPort;
    
    //if the box is local send it on...
    if(local.find(msg->to) != local.end()){
        local[msg->to]->handle(msg);
        msg = NULL;
    }else if(msg->to.compare(getAddress()) == 0 && msg->from.compare(getAddress()) == 0){
        //if we are sending ourselves a message get rid of it
        delete msg;
        msg = NULL;
    }else if(msg->to.compare(getAddress()) == 0){
        //we got a request with out an id so send it to the first box we have
        //this could be a join request... could just make all address be fully qualified
        if(local.size() != 0){
            Mailbox* mb = local.begin()->second;
            mb->handle(msg);
            msg = NULL;
        }else{
            Msg* error = createError(msg,"no nodes");
            delete msg;
            msg = error;
            while(msg != NULL){
                msg = deliver(msg);
            }
        }
    }else{
        //this is not a local address so route it onward
        msg = route(poHost,poPort,msg);
        //handle the couldn't connect... two times through and we get matching to and from
        while(msg != NULL){
            msg = deliver(msg);
        }
    }
    return msg;
}

//read a message off a socket
Msg* PostOffice::readMessage(int socket){
    
    int size = 0;
    int bytes = recv(socket,&size,sizeof(int),MSG_WAITALL);
    if(bytes < 0)
        return NULL;
    
    char* buffer = new char[size+1];
    bytes = recv(socket,buffer,size*sizeof(char),MSG_WAITALL);
    if(bytes < 0)
        return NULL;
    buffer[size] = '\0';
    
    Msg* msg = new Msg();
    
    stringstream parser;
    parser << buffer;
    parser >> msg->to;
    parser >> msg->from;
    string temp;
    getline(parser,temp);
    msg->data = temp.substr(1);
    
    delete buffer;
    
    return msg;
}

//listen for connection requests but time out every 5 seconds
Msg* PostOffice::wait(){
    
    Msg* msg = NULL;
    //Time-out every 5 seconds...
    struct timeval tv;
    tv.tv_sec = 5;
    tv.tv_usec = 0;

    //check for local boxes
    for(map<string,Mailbox*>::iterator it=local.begin(); it != local.end(); ++it){
        Mailbox* mb = it->second;
        while(mb->hasMessages()){
            Msg* msg = mb->post();
            msg = deliver(msg);
        }
    }
    
    fd_set selected = sockets;
    
    select(maxFd+1, &selected, NULL, NULL, &tv);

    if(FD_ISSET(listener,&selected)){
        //handle a connection and read a message
        struct sockaddr_storage address;
        socklen_t size = sizeof(address);
        bzero(&address, sizeof(address));
        int fd = accept(listener, (struct sockaddr *)&address, &size);
        msg = readMessage(fd);
        if(msg != NULL)
            msg = deliver(msg);
        close(fd);
    }
    
    //on a newline construct a msg and send it to the console
    if (FD_ISSET(STDIN_FILENO, &selected)) {
        msg = new Msg();
        msg->to = "console";
        msg->from = "keyboard";
        string theLine;
        getline(cin,theLine);
        msg->writeString(theLine);
    }
    
    return msg;
}
