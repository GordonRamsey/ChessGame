#include "PostOffice.h"
#include "Node.h"
#include <stdlib.h>
#include <sstream>
#include <time.h>
#include <vector>

vector<Node*> nodes;


//trim of leading and trailing whitespace
string trim(string st){
    int i =0;
    while(isspace(st[i]) && i < st.size())
        ++i;
    int j = st.size()-1;
    while(isspace(st[j]) && j >= 0)
        --j;
    if(i > j )
        return "";
    return st.substr(i,j-i+1);
    
}

//finds the address of a node based on id
string findAddress(string n){
    for(int i =0; i < nodes.size(); ++i){
        if(nodes[i]->getId() == n)
            return nodes[i]->getAddress();
    }
    return n;
}

//finds a node based on the address
Node* findNode(string n){
    string aa = findAddress(n);
    for(int i =0; i < nodes.size(); ++i){
        if(nodes[i]->getAddress() == aa)
            return nodes[i];
    }
    return NULL;
}


int main(int argc, char* argv[]){
	PostOffice* po = new PostOffice(argv[1]);

    cout << po->getAddress() << endl;
    
    srand(time(0));
    
    
    //add some nodes...
    //Node* a = new Node("widespread");
    //nodes.push_back(a);
    //po->makeBox(nodes[nodes.size()-1]);

    //you could initialize more nodes here and manually update the neighbors and areas
    //you could draw by looping through the node list
    
    //have all the new nodes join to the first node
    //for(int i =1; i < nodes.size(); ++i){
    //    nodes[i]->join(nodes[0].getAddress());
    //}
    
    //finally add a networked program
    
    
    bool running = true;
    
	while(running){
        //lets the postoffice check the sockets...
		Msg* msg = po->wait();
		if(msg != NULL){
            //handle a message to the console
            string message = msg->data;
            stringstream tokens(message);
            string cmd;
            tokens >> cmd;
            
            if(cmd.compare("quit") == 0){
                running = false;
            }else if(cmd.compare("join") == 0){
                //more complicated than needed, makes sure two nodes don't have the same id...
				string name = "";                
                if(tokens >> name){
                    Node* q = findNode(name);
                    string address = po->getAddress();
                    if(tokens >> cmd){
                        address = cmd;
                    }
                    if(q == NULL){
                        q = new Node(name);
                        nodes.push_back(q);
                        //register the new Node with the postoffice
                        po->makeBox(nodes[nodes.size()-1]);
                        nodes[nodes.size()-1]->join(address);
                    }else{
                        q->join(address);
                    }
                }
            }else if(cmd.compare("list") == 0){
                //lists the nodes that are currently registered with the PostOffice
                po->debug();
            }else if(cmd.compare("send") == 0){
                //send a dummy message to see if we can talk between nodes
                tokens >> cmd;
                Node*  a = findNode(cmd);
                tokens >> cmd;
                string b = findAddress(cmd);
                if(a != NULL){
                    getline(tokens,cmd);
                    a->send(b,trim(cmd));
                }
            }
            
		}
	}

    for(int i =0; i < nodes.size(); ++i){
        delete nodes[i];
    }
    
    delete po;
    
    return 0;
}
