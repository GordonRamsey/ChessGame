#include "Mailbox.h"


string Mailbox::getId(){
    return id;
}

void Mailbox::setAddress(string add){
    address = add;
}

string Mailbox::getAddress(){
    return address;
}

bool Mailbox::hasMessages(){
    return messages.size() != 0;
}

Msg* Mailbox::post(){
    if(messages.size() == 0)
        return NULL;
    Msg* rv = messages[0];
    messages.erase(messages.begin());
    return rv;
}

void Mailbox::print(){
    
}

void Mailbox::handle(Msg* msg){
}