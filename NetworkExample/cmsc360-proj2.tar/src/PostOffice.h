//julian dymacek
//cmsc 360 fall 2015
#ifndef POSTOFFICE__H
#define POSTOFFICE__H
#include <iostream>
#include <sstream>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <stdio.h>
#include <string.h>
#include <netdb.h>
#include <map>
#include "Msg.h"
#include "Mailbox.h"

using namespace std;

//a class for sending and receiving messages
//you shouldn't have to mess with this class
//if it has a bug I will fix it and send out
//out a new copy
class PostOffice{
public:
    PostOffice(string id);
    string getAddress();
    
    void makeBox(Mailbox* mb);
    Msg* route(string server,string port,Msg* msg);
    Msg* deliver(Msg* msg);
    Msg* readMessage(int fd);
    Msg* wait();
    void debug();
    
private:
    Msg* createError(Msg* msg,string error);

    string parseHost(string addr);
    string parsePort(string addr);
    
    
    map<string,Mailbox*> local;
    string hostname;
    string port;
    
    int listener;
    fd_set sockets;
    int maxFd;
    
};

#endif
