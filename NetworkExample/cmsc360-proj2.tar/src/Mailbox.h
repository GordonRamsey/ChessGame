#ifndef MAILBOX__H
#define MAILBOX__H
#include <iostream>
#include "Msg.h"
#include <vector>

using namespace std;

class Mailbox{
public:
    virtual string getId();
    virtual void setAddress(string add);
    virtual string getAddress();
    virtual bool hasMessages();
    virtual Msg* post();
    virtual void print();
    virtual void handle(Msg* msg);

protected:
    string id;
    string address;
    vector<Msg*> messages;
    
    
};

#endif
