#include "Node.h"

Node::Node(string d){
    id = d;
}

//an example function to create a message going to a destination...
void Node::send(string dest,string m){
    Msg* msg = new Msg();
    msg->to = dest;
    msg->from = address;
    msg->data = m;
    
    
    //use this line to send msg
    messages.push_back(msg);
}


void Node::print(){
    cout << "node: " << address << "\n";
    
}

//this function sends a message to dest asking to join...
void Node::join(string dest){

    Msg* msg = new Msg();
    msg->to = dest;
    msg->from = address;
    
    stringstream output;
    output.precision(4);
    
    float x = (float)rand()/(float)RAND_MAX;
    float y = (float)rand()/(float)RAND_MAX;
    
    output << "join " << x << " " << y;
    
    msg->writeString(output.str());
    messages.push_back(msg);
}

//is called when this node recieves a message
//should handle the message and send out messages by using messages.push_back(msg)
//what should happen if it recieves a join message and it doesn't contain the point...
void Node::handle(Msg* msg){
    cout << id << " is handling a msg\n";
    msg->printAsString();
    delete msg;
}
